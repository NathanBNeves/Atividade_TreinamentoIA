<img src="InfoRMI_Logo_Vertical_Branco.svg" alt="Logo InfoRMI" width="140">

# Levantamento dos XMLs

Escopo analisado: primeira pasta de `refs`, `V6-39E001.ap17`. O conjunto contém 1.098 arquivos XML, dos quais 905 estão em `Program blocks`. Os exemplos abaixo foram extraídos de blocos de programa Siemens TIA Portal.

## Bloco de programa

- **Arquivo:** `refs/V6-39E001.ap17/KASTIL1-----BS1---KFU1/Program blocks/VASS_V6/Meldesystem/PD_Meldesystem/PD_Meldesystem.xml`, linhas 54–74.
- **Trecho:** `<SW.Blocks.FB ID="0">`, com entradas `Cfg` e `VkStoe_In`, e saídas `Stoe`, `Warn` e `VkStoe_Out`.

O elemento `SW.Blocks.FB` identifica um *Function Block* (FB), uma unidade reutilizável de lógica do PLC. Neste caso, a interface revela que o bloco trata configuração e encadeamento de falhas, produzindo estados consolidados de falha e aviso.

## Chamada de bloco

- **Arquivo:** `refs/V6-39E001.ap17/KASTIL1-----BS1---KFU1/Program blocks/VASS_V6/Meldesystem/PD_Meldesystem/PD_Meldesystem.xml`, linhas 1623–1649.
- **Trecho:** `<CallInfo ... BlockType="FB" Name="F_Trig">` com instância local `F_Trig_GetAlarmDataReady` e parâmetro `CLK := xAlarmDataReady`.

A chamada a `F_Trig` executa um detector de borda descendente: ela permite que a lógica reaja apenas à transição de `xAlarmDataReady` de verdadeiro para falso, em vez de reagir continuamente enquanto o sinal permanece em determinado estado. A instância local conserva o estado necessário para comparar o ciclo atual ao anterior.

## Variável local temporária

- **Arquivo:** `refs/V6-39E001.ap17/KASTIL1-----BS1---KFU1/Program blocks/VASS_V6/Meldesystem/PD_Meldesystem/PD_Meldesystem.xml`, linhas 114–117.
- **Trecho:** `<Section Name="Temp">` com `uiAnzAlarme : UInt` e `a : Int`.

Variáveis na seção `Temp` existem somente durante a execução do bloco e não retêm valor entre ciclos do PLC. `uiAnzAlarme` é apropriada para contabilizar alarmes e `a` provavelmente atua como índice ou variável auxiliar de cálculo; ambas evitam usar memória persistente para dados transitórios.

## Acesso a membro de DB

- **Arquivo:** `refs/V6-39E001.ap17/KASTIL1-----BS1---KFU1/Program blocks/VASS_V6/Meldesystem/PD_Meldesystem/PD_Meldesystem.xml`, linhas 739–751.
- **Trecho:** `<Access Scope="GlobalVariable">` seguido de `PD_Sortiert_Zeitstp.Meldungen.Init`.
- **Outro exemplo:** linhas 709–717, `DB_ARG.TextListChange`.

O acesso global referencia dados persistentes e compartilhados fora do FB. Em `PD_Sortiert_Zeitstp.Meldungen.Init`, o programa alcança o membro `Init` dentro da estrutura `Meldungen` de um DB; isso centraliza o estado de inicialização das mensagens para que outros blocos possam consultá-lo ou atualizá-lo. `DB_ARG.TextListChange` é outro indicador global usado pela lógica de listas de texto.

## Elementos adicionais relevantes

- **Instância estática:** linha 105, `R_Trig_QuittGlobal`, do tipo `R_Trig`, com estado interno `Edge_flag_pos`.
- **Constante:** linhas 118–120, `PosBW : Int := 5`, descrita como posição de valor auxiliar no *split array*.
- **Sinais funcionais:** linhas 72–74 definem `Stoe` (falha coletiva), `Warn` (aviso coletivo) e `VkStoe_Out` (encadeamento de falha).

Instâncias estáticas preservam seu estado entre ciclos do PLC, o que é indispensável em detectores de borda e máquinas de estados. A constante `PosBW` elimina valores mágicos e documenta a posição usada no array. Já os três sinais de saída constituem a interface principal do sistema de mensagens: consolidam a condição de falha, diferenciam avisos e propagam a cadeia de falhas para a lógica seguinte.

## Itens não identificados

Todos os elementos solicitados — bloco, chamada, variável local e acesso a membro de DB — foram identificados no escopo analisado.

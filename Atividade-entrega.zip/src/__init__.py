"""Pacote da aplicação Explorador de XML VASS06."""

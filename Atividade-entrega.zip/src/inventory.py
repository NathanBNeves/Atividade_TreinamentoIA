"""Leitura segura do inventário de exportações XML."""

from __future__ import annotations

from collections import Counter
from dataclasses import dataclass
from pathlib import Path
from xml.etree import ElementTree


@dataclass(frozen=True)
class AnalysisFailure:
    """Falha encontrada ao analisar um XML, sem interromper o inventário."""

    relative_path: str
    project: str | None
    cpu: str | None
    message: str


@dataclass(frozen=True)
class InventoryReport:
    """Resumo do processamento inicial da árvore de referências."""

    files_found: int
    files_read: int
    failures: tuple[AnalysisFailure, ...]
    projects: tuple[str, ...]
    files_by_project: dict[str, int]
    files_by_cpu: dict[tuple[str, str], int]


def scan_xml_files(refs_root: Path) -> InventoryReport:
    """Conta e valida XMLs sob ``refs_root`` sem alterar os arquivos originais."""
    # Localiza somente XMLs; os arquivos de referência são sempre tratados como leitura.
    xml_paths = sorted(refs_root.rglob("*.xml")) if refs_root.is_dir() else []
    failures: list[AnalysisFailure] = []
    files_by_project: Counter[str] = Counter()
    files_by_cpu: Counter[tuple[str, str]] = Counter()
    projects: set[str] = set()
    files_read = 0

    for xml_path in xml_paths:
        # A estrutura definida do repositório usa os dois primeiros níveis como projeto e CPU.
        relative_parts = xml_path.relative_to(refs_root).parts
        project = relative_parts[0] if relative_parts else None
        cpu = relative_parts[1] if len(relative_parts) > 1 else None

        # Mantém os totais mesmo quando o conteúdo do XML for inválido.
        if project:
            projects.add(project)
            files_by_project[project] += 1
        if project and cpu:
            files_by_cpu[(project, cpu)] += 1

        try:
            # Analisa a estrutura para distinguir arquivos lidos de arquivos com falha.
            ElementTree.parse(xml_path)
        except (ElementTree.ParseError, OSError, UnicodeError) as error:
            failures.append(
                AnalysisFailure(
                    relative_path=xml_path.relative_to(refs_root).as_posix(),
                    project=project,
                    cpu=cpu,
                    message=str(error),
                )
            )
        else:
            files_read += 1

    # Devolve um retrato imutável do processamento para a interface e para a futura indexação.
    return InventoryReport(
        files_found=len(xml_paths),
        files_read=files_read,
        failures=tuple(failures),
        projects=tuple(sorted(projects)),
        files_by_project=dict(sorted(files_by_project.items())),
        files_by_cpu=dict(sorted(files_by_cpu.items())),
    )

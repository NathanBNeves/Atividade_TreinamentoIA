"""Persistência SQLite do índice de ocorrências XML."""

from __future__ import annotations

from collections import Counter
from contextlib import closing
from dataclasses import dataclass
from pathlib import Path
import sqlite3
from xml.etree import ElementTree

from src.extractor import Occurrence, extract_occurrences


UNSUPPORTED_STRUCTURES = (
    "leituras e escritas",
    "acesso a membro de DB",
    "associação entre um nome citado e um comentário",
)


@dataclass(frozen=True)
class IndexReport:
    """Resultado da criação do índice consultado pela interface."""

    files_processed: int
    failures: tuple[str, ...]
    occurrences_by_category: dict[str, int]
    unsupported_structures: tuple[str, ...]

    @property
    def occurrences_count(self) -> int:
        """Soma as ocorrências de todas as categorias extraídas."""
        return sum(self.occurrences_by_category.values())


@dataclass(frozen=True)
class SearchResult:
    """Ocorrência retornada pela busca, pronta para apresentação na interface."""

    id: int
    name: str
    category: str
    role: str
    project: str
    cpu: str | None
    relative_path: str
    location: str
    snippet: str
    confidence: str
    reason: str


def build_index(refs_root: Path, database_path: Path) -> IndexReport:
    """Reconstrói o índice local a partir das declarações XML suportadas."""
    database_path.parent.mkdir(parents=True, exist_ok=True)
    # Fecha a conexão explicitamente para não bloquear o arquivo SQLite no Windows.
    with closing(sqlite3.connect(database_path)) as connection:
        _create_schema(connection)
        # A reconstrução evita manter dados obsoletos após uma nova exportação do projeto.
        connection.execute("DELETE FROM occurrences")
        category_counts: Counter[str] = Counter()
        failures: list[str] = []
        files_processed = 0

        for xml_path in sorted(refs_root.rglob("*.xml")):
            try:
                occurrences = extract_occurrences(xml_path, refs_root)
            except (ElementTree.ParseError, OSError, UnicodeError) as error:
                failures.append(f"{xml_path.relative_to(refs_root).as_posix()}: {error}")
                continue

            _insert_occurrences(connection, occurrences)
            category_counts.update(occurrence.category for occurrence in occurrences)
            files_processed += 1

        connection.commit()

    return IndexReport(
        files_processed=files_processed,
        failures=tuple(failures),
        occurrences_by_category=dict(sorted(category_counts.items())),
        unsupported_structures=UNSUPPORTED_STRUCTURES,
    )


def read_index_report(database_path: Path, files_processed: int, failures: tuple[str, ...]) -> IndexReport:
    """Lê os totais do índice existente sem reprocessar os XMLs a cada inicialização."""
    with closing(sqlite3.connect(database_path)) as connection:
        rows = connection.execute(
            "SELECT category, COUNT(*) FROM occurrences GROUP BY category ORDER BY category"
        ).fetchall()

    return IndexReport(
        files_processed=files_processed,
        failures=failures,
        occurrences_by_category=dict(rows),
        unsupported_structures=UNSUPPORTED_STRUCTURES,
    )


def search_occurrences(
    database_path: Path,
    query: str,
    match_mode: str,
    project: str | None = None,
    cpu: str | None = None,
    category: str | None = None,
    limit: int = 100,
    offset: int = 0,
) -> tuple[int, list[SearchResult]]:
    """Pesquisa o índice com filtros combinados, sem reler qualquer XML."""
    normalized_query = query.strip()
    where_parts = ["1 = 1"]
    parameters: list[str | int] = []
    if normalized_query:
        # Caracteres especiais são texto de busca, não curingas SQL.
        if match_mode == "partial":
            escaped = normalized_query.replace("\\", "\\\\").replace("%", "\\%").replace("_", "\\_")
            where_parts.append("name LIKE ? ESCAPE '\\' COLLATE NOCASE")
            parameters.append(f"%{escaped}%")
        else:
            where_parts.append("name = ? COLLATE NOCASE")
            parameters.append(normalized_query)

    # Cada filtro acrescenta uma condição independente, permitindo combinações previsíveis.
    for column, value in (("project", project), ("cpu", cpu), ("category", category)):
        if value:
            where_parts.append(f"{column} = ?")
            parameters.append(value)

    where_clause = " AND ".join(where_parts)
    with closing(sqlite3.connect(database_path)) as connection:
        total = connection.execute(
            f"SELECT COUNT(*) FROM occurrences WHERE {where_clause}", parameters
        ).fetchone()[0]
        rows = connection.execute(
            f"""
            SELECT id, name, category, role, project, cpu, relative_path, location, snippet, confidence, reason
            FROM occurrences
            WHERE {where_clause}
            ORDER BY name COLLATE NOCASE, project, cpu, relative_path
            LIMIT ? OFFSET ?
            """,
            [*parameters, limit, max(0, offset)],
        ).fetchall()

    return total, [SearchResult(*row) for row in rows]


def navigation_tree(database_path: Path) -> dict[str, dict[str, dict[str, int]]]:
    """Agrupa as ocorrências indexadas em projeto, CPU e categoria."""
    tree: dict[str, dict[str, dict[str, int]]] = {}
    with closing(sqlite3.connect(database_path)) as connection:
        rows = connection.execute("""
            SELECT project, cpu, category, COUNT(*) FROM occurrences
            WHERE cpu IS NOT NULL GROUP BY project, cpu, category ORDER BY project, cpu, category
        """)
        for project, cpu, category, count in rows:
            tree.setdefault(project, {}).setdefault(cpu, {})[category] = count
    return tree


def get_occurrence(database_path: Path, occurrence_id: int) -> SearchResult | None:
    """Obtém uma ocorrência pelo identificador para a página de detalhe."""
    with closing(sqlite3.connect(database_path)) as connection:
        row = connection.execute(
            """
            SELECT id, name, category, role, project, cpu, relative_path, location, snippet, confidence, reason
            FROM occurrences WHERE id = ?
            """,
            (occurrence_id,),
        ).fetchone()
    return SearchResult(*row) if row else None


def list_filter_values(database_path: Path) -> tuple[list[str], list[str], list[str]]:
    """Lista filtros disponíveis a partir do índice persistido."""
    with closing(sqlite3.connect(database_path)) as connection:
        projects = [row[0] for row in connection.execute("SELECT DISTINCT project FROM occurrences ORDER BY project")]
        cpus = [row[0] for row in connection.execute("SELECT DISTINCT cpu FROM occurrences WHERE cpu IS NOT NULL ORDER BY cpu")]
        categories = [row[0] for row in connection.execute("SELECT DISTINCT category FROM occurrences ORDER BY category")]
    return projects, cpus, categories


def _create_schema(connection: sqlite3.Connection) -> None:
    """Cria a tabela e os índices necessários para as consultas das etapas seguintes."""
    connection.executescript(
        """
        CREATE TABLE IF NOT EXISTS occurrences (
            id INTEGER PRIMARY KEY,
            name TEXT NOT NULL,
            category TEXT NOT NULL,
            role TEXT NOT NULL,
            project TEXT NOT NULL,
            cpu TEXT,
            relative_path TEXT NOT NULL,
            location TEXT NOT NULL,
            snippet TEXT NOT NULL,
            confidence TEXT NOT NULL,
            reason TEXT NOT NULL
        );
        CREATE INDEX IF NOT EXISTS idx_occurrences_name ON occurrences(name COLLATE NOCASE);
        CREATE INDEX IF NOT EXISTS idx_occurrences_filters
            ON occurrences(project, cpu, category);
        """
    )
    # Atualiza bancos criados na etapa anterior sem exigir que o usuário apague o índice.
    columns = {row[1] for row in connection.execute("PRAGMA table_info(occurrences)")}
    if "reason" not in columns:
        connection.execute("ALTER TABLE occurrences ADD COLUMN reason TEXT NOT NULL DEFAULT ''")


def _insert_occurrences(connection: sqlite3.Connection, occurrences: list[Occurrence]) -> None:
    """Armazena em lote as declarações extraídas de um mesmo XML."""
    connection.executemany(
        """
        INSERT INTO occurrences (
            name, category, role, project, cpu, relative_path, location, snippet, confidence, reason
        ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
        """,
        [
            (
                occurrence.name,
                occurrence.category,
                occurrence.role,
                occurrence.project,
                occurrence.cpu,
                occurrence.relative_path,
                occurrence.location,
                occurrence.snippet,
                occurrence.confidence,
                occurrence.reason,
            )
            for occurrence in occurrences
        ],
    )

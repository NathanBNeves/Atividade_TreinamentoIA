"""Ponto de entrada da aplicação web local."""

from pathlib import Path

from flask import Flask, abort, render_template, request, send_from_directory

from src.index_store import build_index, get_occurrence, list_filter_values, navigation_tree, read_index_report, search_occurrences
from src.inventory import scan_xml_files
from src.source_context import inspect_source


SUPPORTED_ROLES = (
    "declaração",
    "chamada",
    "instância",
    "referência de tipo",
    "comentário",
)

CATEGORY_DESCRIPTIONS = {
    "block": "FB, FC ou OB declarado, ou uma chamada explícita de bloco.",
    "comment": "Texto contido em comentário XML; não comprova uso de nomes citados.",
    "constant": "Valor literal encontrado no código exportado.",
    "db": "Data block global declarado.",
    "db_member": "Campo declarado dentro de um DB global.",
    "instance": "Instância associada explicitamente a uma chamada de FB.",
    "local_variable": "Membro declarado na interface de um bloco.",
    "tag": "Tag global declarada em uma tabela de tags.",
    "type": "Tipo declarado ou referência explícita de tipo em Datatype.",
}

CATEGORY_LABELS = {
    "block": "Blocos", "comment": "Comentários", "constant": "Constantes",
    "db": "DBs", "db_member": "Membros de DB", "instance": "Instâncias",
    "local_variable": "Variáveis locais", "tag": "Tags", "type": "Tipos",
}


def create_app() -> Flask:
    """Cria e configura a aplicação Flask."""
    # Mantém templates e estilos da interface reunidos em src/web/.
    application = Flask(
        __name__,
        template_folder="web/templates",
        static_folder="web/static",
        static_url_path="/static",
    )
    # Faz o inventário uma vez na inicialização; filtros futuros consultarão dados indexados.
    project_root = Path(__file__).resolve().parents[1]
    references_directory = project_root / "refs"
    inventory = scan_xml_files(references_directory)
    # Persiste uma vez as declarações suportadas para que a busca futura não releia os XMLs.
    database_path = project_root / "data" / "index.sqlite3"
    if database_path.exists():
        # Reutiliza o índice existente; a atualização explícita será acrescentada à interface depois.
        index_report = read_index_report(
            database_path,
            inventory.files_read,
            tuple(failure.message for failure in inventory.failures),
        )
    else:
        index_report = build_index(references_directory, database_path)
    projects, cpus, categories = list_filter_values(database_path)
    tree = navigation_tree(database_path)

    @application.get("/")
    def index() -> str:
        """Exibe a página inicial enquanto a indexação não foi implementada."""
        # Lê os filtros da URL para tornar uma pesquisa compartilhável e fácil de repetir.
        query = request.args.get("q", "").strip()
        match_mode = request.args.get("match", "partial")
        match_mode = match_mode if match_mode in {"exact", "partial"} else "partial"
        project = request.args.get("project") or None
        cpu = request.args.get("cpu") or None
        category = request.args.get("category") or None
        page = max(1, request.args.get("page", 1, type=int) or 1)
        browsing = bool(request.args)
        total, results = search_occurrences(
            database_path,
            query,
            match_mode,
            project=project,
            cpu=cpu,
            category=category,
            limit=50,
            offset=(page - 1) * 50,
        ) if browsing else (0, [])
        # Entrega o resumo e as limitações sem declarar como confiáveis dados não interpretados.
        return render_template(
            "index.html",
            inventory=inventory,
            index_report=index_report,
            supported_roles=SUPPORTED_ROLES,
            projects=projects,
            cpus=cpus,
            categories=categories,
            query=query,
            match_mode=match_mode,
            selected_project=project,
            selected_cpu=cpu,
            selected_category=category,
            total=total,
            results=results,
            category_descriptions=CATEGORY_DESCRIPTIONS,
            category_labels=CATEGORY_LABELS,
            has_analysis_issues=bool(inventory.failures or index_report.failures),
            tree=tree,
            browsing=browsing,
            page=page,
            total_pages=max(1, (total + 49) // 50),
        )

    @application.get("/occurrences/<int:occurrence_id>")
    def occurrence_detail(occurrence_id: int) -> str:
        """Exibe a árvore de origem e o trecho de uma ocorrência selecionada."""
        occurrence = get_occurrence(database_path, occurrence_id)
        if occurrence is None:
            abort(404)
        # O contexto é calculado apenas para a seleção aberta, não durante cada pesquisa.
        context = inspect_source(references_directory, occurrence)
        return render_template("occurrence_detail.html", occurrence=occurrence, context=context)

    @application.get("/brand/logo")
    def brand_logo() -> object:
        """Disponibiliza o logo vertical original, preservado na raiz do projeto."""
        return send_from_directory(project_root, "InfoRMI_Logo_Vertical_Branco.svg")

    @application.get("/brand/symbol")
    def brand_symbol() -> object:
        """Disponibiliza o símbolo colorido original para a composição da interface."""
        return send_from_directory(project_root, "InfoRMI_Símbolo_Colorido.svg")

    return application


app = create_app()


if __name__ == "__main__":
    app.run(host="127.0.0.1", port=5000)

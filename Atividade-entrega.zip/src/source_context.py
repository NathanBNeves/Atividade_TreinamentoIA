"""Contexto de origem apresentado ao abrir uma ocorrência indexada."""

from __future__ import annotations

from dataclasses import dataclass
from pathlib import Path
from xml.etree import ElementTree

from src.index_store import SearchResult
from src.extractor import _attribute_name


@dataclass(frozen=True)
class SourceContext:
    """Metadados reconstruídos do XML sem afirmar precisão inexistente."""

    block_kind: str | None
    block_name: str | None
    candidate_line: int | None
    line_note: str
    path_parts: tuple[str, ...]


def inspect_source(refs_root: Path, occurrence: SearchResult) -> SourceContext:
    """Localiza bloco e linha candidata no arquivo de origem da ocorrência."""
    source_path = refs_root / Path(occurrence.relative_path)
    block_kind, block_name = _find_block_context(source_path)
    line_number = _find_candidate_line(source_path, occurrence)
    line_note = (
        "Linha candidata no XML original; confirme pelo elemento e trecho exibidos."
        if line_number is not None
        else "Linha não identificada com segurança: o nome pode aparecer várias vezes ou não estar disponível no arquivo."
    )
    return SourceContext(
        block_kind=block_kind,
        block_name=block_name,
        candidate_line=line_number,
        line_note=line_note,
        path_parts=Path(occurrence.relative_path).parts,
    )


def _find_block_context(source_path: Path) -> tuple[str | None, str | None]:
    """Busca a raiz FB, FC, OB ou DB declarada no arquivo de origem."""
    try:
        root = ElementTree.parse(source_path).getroot()
    except (ElementTree.ParseError, OSError, UnicodeError):
        return None, None

    for element in root.iter():
        tag_name = _local_name(element.tag)
        if tag_name in {"SW.Blocks.FB", "SW.Blocks.FC", "SW.Blocks.OB", "SW.Blocks.GlobalDB"}:
            return tag_name.removeprefix("SW.Blocks."), _attribute_name(element) or source_path.stem
    return None, None


def _find_candidate_line(source_path: Path, occurrence: SearchResult) -> int | None:
    """Encontra uma linha candidata com marcador explícito, sem alegar unicidade."""
    try:
        lines = source_path.read_text(encoding="utf-8").splitlines()
    except (OSError, UnicodeError):
        return None

    markers = (f'Name="{occurrence.name}"', f">{occurrence.name}<")
    candidates = [number for number, line in enumerate(lines, start=1) if any(marker in line for marker in markers)]
    if len(candidates) == 1:
        return candidates[0]
    return None


def _first_text(element: ElementTree.Element, tag_name: str) -> str | None:
    """Obtém um texto de elemento ignorando namespaces da exportação."""
    for child in element.iter():
        if _local_name(child.tag) == tag_name and child.text and child.text.strip():
            return child.text.strip()
    return None


def _local_name(tag_name: str) -> str:
    """Remove namespaces XML para comparar tags da exportação."""
    return tag_name.rsplit("}", maxsplit=1)[-1]

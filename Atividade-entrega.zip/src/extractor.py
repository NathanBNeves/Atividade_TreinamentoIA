"""Extração conservadora de declarações explícitas dos XMLs do TIA Portal."""

from __future__ import annotations

from dataclasses import dataclass
from pathlib import Path
from xml.etree import ElementTree


@dataclass(frozen=True)
class Occurrence:
    """Elemento pesquisável com sua origem e o grau de certeza da leitura."""

    name: str
    category: str
    role: str
    project: str
    cpu: str | None
    relative_path: str
    location: str
    snippet: str
    confidence: str
    reason: str


def extract_occurrences(xml_path: Path, refs_root: Path) -> list[Occurrence]:
    """Extrai apenas elementos cuja declaração é explícita no XML."""
    root = ElementTree.parse(xml_path).getroot()
    relative_path = xml_path.relative_to(refs_root).as_posix()
    path_parts = xml_path.relative_to(refs_root).parts
    project = path_parts[0]
    cpu = path_parts[1] if len(path_parts) > 1 else None
    occurrences: list[Occurrence] = []

    # Cada bloco raiz tem uma categoria inequívoca na exportação do TIA Portal.
    for element in root.iter():
        block_category = _block_category(_local_name(element.tag))
        if block_category:
            # Name identifica o bloco; HeaderName é outro metadado e pode diferir.
            block_name = _attribute_name(element) or xml_path.stem
            occurrences.append(
                _occurrence(
                    name=block_name,
                    category=block_category,
                    role="declaration",
                    project=project,
                    cpu=cpu,
                    relative_path=relative_path,
                    location=_local_name(element.tag),
                    element=element,
                )
            )
            # Membros abaixo de um DB global não são variáveis locais.
            member_category = "db_member" if block_category == "db" else "local_variable"
            occurrences.extend(
                _members_in_block(
                    element,
                    member_category,
                    project,
                    cpu,
                    relative_path,
                )
            )

        # Tags globais têm o nome declarado em AttributeList/Name.
        if _local_name(element.tag) == "SW.Tags.PlcTag":
            tag_name = _first_child_text(element, "Name")
            if tag_name:
                occurrences.append(
                    _occurrence(
                        name=tag_name,
                        category="tag",
                        role="declaration",
                        project=project,
                        cpu=cpu,
                        relative_path=relative_path,
                        location="SW.Tags.PlcTag",
                        element=element,
                    )
                )

        # Tipos definidos têm uma declaração explícita e não dependem da linguagem do bloco.
        if _local_name(element.tag) == "SW.Types.PlcStruct":
            type_name = _first_child_text(element, "Name") or xml_path.stem
            occurrences.append(
                _occurrence(
                    name=type_name,
                    category="type",
                    role="declaration",
                    project=project,
                    cpu=cpu,
                    relative_path=relative_path,
                    location="SW.Types.PlcStruct",
                    element=element,
                )
            )

        # CallInfo é a forma explícita de chamada preservada nas linguagens exportadas.
        if _local_name(element.tag) == "CallInfo" and element.get("Name"):
            occurrences.append(
                _occurrence(
                    name=element.attrib["Name"],
                    category="block",
                    role="call",
                    project=project,
                    cpu=cpu,
                    relative_path=relative_path,
                    location="CallInfo",
                    element=element,
                    reason="Elemento CallInfo explícito na exportação.",
                )
            )
            instance = next((child for child in element if _local_name(child.tag) == "Instance"), None)
            instance_name = _first_component_name(instance) if instance is not None else None
            if instance_name:
                occurrences.append(
                    _occurrence(
                        name=instance_name,
                        category="instance",
                        role="instance",
                        project=project,
                        cpu=cpu,
                        relative_path=relative_path,
                        location="CallInfo/Instance",
                        element=instance,
                        reason="Instância explicitamente ligada a uma chamada CallInfo.",
                    )
                )

        # Comentários são indexados pelo próprio texto; eles não provam uso de um nome citado.
        if _local_name(element.tag) in {"Comment", "LineComment"}:
            comment_text = _first_comment_text(element)
            if comment_text:
                occurrences.append(
                    _occurrence(
                        name=comment_text[:500],
                        category="comment",
                        role="comment",
                        project=project,
                        cpu=cpu,
                        relative_path=relative_path,
                        location=_local_name(element.tag),
                        element=element,
                        reason="Texto armazenado em elemento de comentário do XML.",
                    )
                )

        # Constantes literais têm escopo próprio no XML e não precisam de inferência textual.
        if _local_name(element.tag) == "Access" and element.get("Scope") == "LiteralConstant":
            constant_value = _first_child_text(element, "ConstantValue") or _first_child_text(element, "Constant")
            if constant_value:
                occurrences.append(
                    _occurrence(
                        name=constant_value,
                        category="constant",
                        role="declaration",
                        project=project,
                        cpu=cpu,
                        relative_path=relative_path,
                        location="Access[LiteralConstant]",
                        element=element,
                        reason="Constante literal identificada pelo escopo LiteralConstant.",
                    )
                )

    return occurrences


def _members_in_block(
    block: ElementTree.Element,
    category: str,
    project: str,
    cpu: str | None,
    relative_path: str,
) -> list[Occurrence]:
    """Extrai membros de seções da interface, preservando a seção como localização."""
    occurrences: list[Occurrence] = []
    for section in block.iter():
        if _local_name(section.tag) != "Section":
            continue
        section_name = section.get("Name", "desconhecida")
        # Considera somente filhos diretos para não duplicar campos de estruturas aninhadas.
        for member in list(section):
            if _local_name(member.tag) != "Member" or not member.get("Name"):
                continue
            occurrences.append(
                _occurrence(
                    name=member.attrib["Name"],
                    category=category,
                    role="declaration",
                    project=project,
                    cpu=cpu,
                    relative_path=relative_path,
                    location=f"Section[{section_name}]",
                    element=member,
                )
            )
            datatype = member.get("Datatype", "")
            custom_type = datatype.strip('"') if datatype.startswith('"') else None
            if custom_type:
                # A referência preserva o tipo definido pelo usuário, sem confundir tipos nativos.
                occurrences.append(
                    _occurrence(
                        name=custom_type,
                        category="type",
                        role="type_reference",
                        project=project,
                        cpu=cpu,
                        relative_path=relative_path,
                        location=f"Section[{section_name}]/Member[{member.attrib['Name']}]",
                        element=member,
                        reason="Atributo Datatype referencia um tipo entre aspas.",
                    )
                )
    return occurrences


def _occurrence(
    *,
    name: str,
    category: str,
    role: str,
    project: str,
    cpu: str | None,
    relative_path: str,
    location: str,
    element: ElementTree.Element,
    reason: str = "Declaração explícita no XML.",
) -> Occurrence:
    """Monta a ocorrência e limita o trecho para manter o índice leve."""
    snippet = ElementTree.tostring(element, encoding="unicode", short_empty_elements=True)
    return Occurrence(
        name=name,
        category=category,
        role=role,
        project=project,
        cpu=cpu,
        relative_path=relative_path,
        location=location,
        snippet=snippet[:2_000],
        confidence="high",
        reason=reason,
    )


def _block_category(tag_name: str) -> str | None:
    """Mapeia as declarações de bloco que a exportação identifica sem ambiguidade."""
    categories = {
        "SW.Blocks.FB": "block",
        "SW.Blocks.FC": "block",
        "SW.Blocks.OB": "block",
        "SW.Blocks.GlobalDB": "db",
    }
    return categories.get(tag_name)


def _first_child_text(element: ElementTree.Element, tag_name: str) -> str | None:
    """Obtém o primeiro texto não vazio de um elemento, ignorando namespaces XML."""
    for child in element.iter():
        if _local_name(child.tag) == tag_name and child.text and child.text.strip():
            return child.text.strip()
    return None


def _attribute_name(element: ElementTree.Element) -> str | None:
    """Lê somente AttributeList/Name, sem confundir nomes de elementos filhos."""
    for attributes in element:
        if _local_name(attributes.tag) == "AttributeList":
            for child in attributes:
                if _local_name(child.tag) == "Name" and child.text and child.text.strip():
                    return child.text.strip()
    return None


def _first_component_name(element: ElementTree.Element | None) -> str | None:
    """Obtém o primeiro componente que nomeia uma instância de chamada."""
    if element is None:
        return None
    for child in element.iter():
        if _local_name(child.tag) == "Component" and child.get("Name"):
            return child.attrib["Name"]
    return None


def _first_comment_text(element: ElementTree.Element) -> str | None:
    """Obtém o primeiro texto de comentário disponível, independentemente do idioma."""
    for child in element.iter():
        if _local_name(child.tag) in {"MultiLanguageText", "Text"} and child.text:
            text = child.text.strip()
            if text:
                return text
    return None


def _local_name(tag_name: str) -> str:
    """Remove o namespace para comparar tags de exportações com versões diferentes."""
    return tag_name.rsplit("}", maxsplit=1)[-1]

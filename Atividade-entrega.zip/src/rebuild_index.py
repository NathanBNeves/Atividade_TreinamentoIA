"""Comando interno para reconstruir o índice local das referências XML."""

from pathlib import Path

from src.index_store import build_index


def main() -> None:
    """Reconstrói o banco em data/ e mostra um resumo no terminal."""
    project_root = Path(__file__).resolve().parents[1]
    # O comando lê refs/ e grava somente o banco local ignorado pelo Git.
    report = build_index(project_root / "refs", project_root / "data" / "index.sqlite3")
    print(f"XMLs processados: {report.files_processed}")
    print(f"Falhas: {len(report.failures)}")
    print(f"Ocorrências: {report.occurrences_count}")


if __name__ == "__main__":
    main()

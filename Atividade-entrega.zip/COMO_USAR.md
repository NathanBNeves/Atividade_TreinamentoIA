# Como usar o Explorador de XML VASS06

## Requisitos

- Windows com Python 3.13 ou superior.
- Ambiente virtual `.venv` com as dependências de `requirements.txt` instaladas.
- A pasta `refs/` com as exportações XML originais, preservada sem alterações.

## Instalação

No terminal integrado do VS Code, na raiz do projeto:

```powershell
py -3.13 -m venv .venv
.\.venv\Scripts\python.exe -m pip install -r requirements.txt
```

Se desejar ativar o ambiente nesta sessão do PowerShell:

```powershell
Set-ExecutionPolicy -Scope Process -ExecutionPolicy Bypass
.\.venv\Scripts\Activate.ps1
```

## Execução

Inicie a aplicação local:

```powershell
.\.venv\Scripts\python.exe -m src.app
```

Abra `http://127.0.0.1:5000` no navegador. Na primeira execução sem banco local, a aplicação criará `data/index.sqlite3`; nas próximas, reutilizará esse índice.

Para reconstruir o índice após trocar o conteúdo de `refs/`, execute:

```powershell
.\.venv\Scripts\python.exe -m src.rebuild_index
```

## Pesquisa e filtros

1. Digite o nome ou texto a procurar, se souber. O campo pode ficar vazio.
2. Escolha **Parte do nome** para uma busca parcial, ou **Nome exato**.
3. Opcionalmente combine os filtros de projeto, CPU e categoria.
4. Clique em **Explorar**. Use **Limpar filtros** para reiniciar a consulta. Navegue pelas páginas para ver todos os resultados encontrados.

Na seção **Explore os projetos**, abra um projeto e depois uma CPU. Selecione **Tudo desta CPU** ou uma categoria, como **DBs**, para consultar o índice sem saber o nome. As contagens representam ocorrências indexadas, não necessariamente itens únicos. O detalhe de cada resultado mostra sua árvore de origem.

As buscas não diferenciam maiúsculas de minúsculas. Cada resultado mostra categoria, papel, projeto, CPU, arquivo relativo, localização XML, confiança, motivo e trecho original.

Para investigar um resultado, use **Abrir análise da ocorrência**. A nova página mostra a árvore de origem com projeto, CPU, pastas, arquivo XML, bloco ou função quando identificável, elemento XML e a ocorrência selecionada. A linha exibida é uma candidata no arquivo original; quando a exportação concentra elementos na mesma linha, a própria página informa essa limitação.

Exemplos:

- Pesquise `FB_Ventil` com **Nome exato** e categoria `block` para localizar declarações e chamadas com esse nome.
- Pesquise `Ventil` com **Parte do nome** para incluir nomes semelhantes e tags relacionadas.
- Selecione um projeto e uma CPU para restringir a origem dos resultados.

## Categorias atualmente indexadas

- `block`: declarações de FB, FC e OB, além de chamadas explícitas.
- `db` e `db_member`: DBs globais e seus campos declarados.
- `tag`: tags globais declaradas.
- `local_variable`: membros declarados em interfaces de blocos.
- `instance`: instâncias associadas a chamadas explícitas.
- `constant`: constantes literais no XML exportado.
- `type`: tipos declarados e referências explícitas por `Datatype`.
- `comment`: texto de comentários XML.

## Testes

Execute a suíte automatizada com:

```powershell
.\.venv\Scripts\python.exe -m unittest discover -s tests -v
```

## Limitações conhecidas

- Leituras, escritas e acesso a membros de DB dentro do código das linguagens ainda não são interpretados.
- Um comentário que cita um nome não comprova que esse nome seja usado pela lógica.
- As buscas e a árvore cobrem somente as estruturas interpretadas; a reconstrução do índice pode alterar os identificadores dos links de detalhe.
- Um resultado vazio vale apenas para as estruturas indexadas; consulte as limitações e eventuais falhas mostradas na página antes de concluir que um elemento não existe.
- O banco em `data/` é local e ignorado pelo Git. Não versione os XMLs de `refs/`, o banco, logs ou o ambiente virtual.

"""Testes do inventário de XMLs."""

from pathlib import Path
from tempfile import TemporaryDirectory
import unittest

from src.inventory import scan_xml_files


class ScanXmlFilesTests(unittest.TestCase):
    """Cobertura para arquivos válidos e inválidos no inventário."""

    def test_counts_valid_and_invalid_xml_without_stopping(self) -> None:
        with TemporaryDirectory() as temporary_directory:
            refs_root = Path(temporary_directory)
            cpu_directory = refs_root / "ProjetoA" / "CPU_1"
            cpu_directory.mkdir(parents=True)
            # A fixture separa um XML legível de outro malformado na mesma CPU.
            (cpu_directory / "valid.xml").write_text("<Document />", encoding="utf-8")
            (cpu_directory / "invalid.xml").write_text("<Document>", encoding="utf-8")

            report = scan_xml_files(refs_root)

        self.assertEqual(report.files_found, 2)
        self.assertEqual(report.files_read, 1)
        self.assertEqual(len(report.failures), 1)
        self.assertEqual(report.projects, ("ProjetoA",))
        self.assertEqual(report.files_by_project, {"ProjetoA": 2})
        self.assertEqual(report.files_by_cpu, {("ProjetoA", "CPU_1"): 2})
        self.assertEqual(report.failures[0].relative_path, "ProjetoA/CPU_1/invalid.xml")

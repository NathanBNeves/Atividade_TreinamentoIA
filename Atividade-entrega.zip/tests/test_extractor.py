"""Testes das declarações XML que a primeira versão do extrator suporta."""

from pathlib import Path
from tempfile import TemporaryDirectory
import sqlite3
from contextlib import closing
import unittest

from src.extractor import extract_occurrences
from src.index_store import build_index, read_index_report


SAMPLE_XML = """<?xml version="1.0" encoding="utf-8"?>
<Document>
  <SW.Blocks.FB><AttributeList><Name>FB_Exemplo</Name><HeaderName>OUTRO</HeaderName>
    <Interface><Sections><Section Name="Input"><Member Name="entrada" Datatype="Bool" /></Section></Sections></Interface>
  </AttributeList></SW.Blocks.FB>
  <SW.Blocks.GlobalDB><AttributeList><Name>DB_Exemplo</Name><HeaderName>OUTRO_DB</HeaderName>
    <Interface><Sections><Section Name="Static"><Member Name="campo" Datatype="Int" /></Section></Sections></Interface>
  </AttributeList></SW.Blocks.GlobalDB>
  <SW.Tags.PlcTag><AttributeList><Name>Tag_Exemplo</Name></AttributeList></SW.Tags.PlcTag>
  <SW.Types.PlcStruct><AttributeList><Name>Tipo_Exemplo</Name></AttributeList></SW.Types.PlcStruct>
  <CallInfo Name="FB_Chamado"><Instance><Component Name="instancia_1" /></Instance></CallInfo>
  <Comment><MultiLanguageText Lang="pt-BR">Comentário de teste</MultiLanguageText></Comment>
  <Access Scope="LiteralConstant"><Constant><ConstantValue>42</ConstantValue></Constant></Access>
</Document>
"""


class ExtractOccurrencesTests(unittest.TestCase):
    """Garante a extração somente de declarações explícitas e verificáveis."""

    def test_extracts_supported_declarations_and_persists_them(self) -> None:
        with TemporaryDirectory() as temporary_directory:
            refs_root = Path(temporary_directory) / "refs"
            xml_directory = refs_root / "ProjetoA" / "CPU_1"
            xml_directory.mkdir(parents=True)
            xml_path = xml_directory / "sample.xml"
            xml_path.write_text(SAMPLE_XML, encoding="utf-8")

            # Confere as categorias antes de qualquer gravação no banco local.
            occurrences = extract_occurrences(xml_path, refs_root)
            categories_by_name = {(item.name, item.category) for item in occurrences}
            self.assertIn(("FB_Exemplo", "block"), categories_by_name)
            self.assertIn(("entrada", "local_variable"), categories_by_name)
            self.assertIn(("DB_Exemplo", "db"), categories_by_name)
            self.assertIn(("campo", "db_member"), categories_by_name)
            self.assertIn(("Tag_Exemplo", "tag"), categories_by_name)
            self.assertIn(("Tipo_Exemplo", "type"), categories_by_name)
            self.assertIn(("FB_Chamado", "block"), categories_by_name)
            self.assertIn(("instancia_1", "instance"), categories_by_name)
            self.assertIn(("Comentário de teste", "comment"), categories_by_name)
            self.assertIn(("42", "constant"), categories_by_name)

            database_path = Path(temporary_directory) / "data" / "index.sqlite3"
            report = build_index(refs_root, database_path)

            # A leitura posterior reutiliza o banco, sem depender da árvore de XMLs.
            loaded_report = read_index_report(database_path, report.files_processed, report.failures)

            # O banco é a fonte de dados das pesquisas que serão implementadas mais adiante.
            with closing(sqlite3.connect(database_path)) as connection:
                stored_count = connection.execute("SELECT COUNT(*) FROM occurrences").fetchone()[0]

        self.assertEqual(report.files_processed, 1)
        self.assertEqual(report.failures, ())
        self.assertEqual(stored_count, 10)
        self.assertEqual(loaded_report.occurrences_by_category["block"], 2)

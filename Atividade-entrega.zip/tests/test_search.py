"""Testes de busca no índice SQLite."""

from pathlib import Path
from tempfile import TemporaryDirectory
import unittest

from src.index_store import build_index, get_occurrence, search_occurrences
from src.source_context import inspect_source


SEARCH_XML = """<Document>
  <SW.Blocks.FB><AttributeList><Name>FB_Ventil</Name><HeaderName>VENTIL</HeaderName></AttributeList></SW.Blocks.FB>
  <SW.Blocks.FB><AttributeList><Name>FB_Ventil_Aux</Name></AttributeList></SW.Blocks.FB>
  <SW.Tags.PlcTag><AttributeList><Name>Tag_Ventil</Name></AttributeList></SW.Tags.PlcTag>
</Document>"""


class SearchOccurrencesTests(unittest.TestCase):
    """Confirma busca sem distinção de caixa e combinação de filtros."""

    def test_finds_exact_and_partial_names_with_filters(self) -> None:
        with TemporaryDirectory() as temporary_directory:
            root = Path(temporary_directory)
            xml_directory = root / "refs" / "ProjetoA" / "CPU_1"
            xml_directory.mkdir(parents=True)
            (xml_directory / "sample.xml").write_text(SEARCH_XML, encoding="utf-8")
            database_path = root / "data" / "index.sqlite3"
            build_index(root / "refs", database_path)

            # A busca parcial encontra nomes semelhantes, mesmo com caixa diferente.
            partial_total, partial_results = search_occurrences(database_path, "ventil", "partial")
            exact_total, exact_results = search_occurrences(
                database_path,
                "fb_ventil",
                "exact",
                project="ProjetoA",
                cpu="CPU_1",
                category="block",
            )
            missing_total, missing_results = search_occurrences(database_path, "inexistente", "exact")
            all_total, first_page = search_occurrences(database_path, "", "partial", project="ProjetoA", cpu="CPU_1", limit=1)
            _, second_page = search_occurrences(database_path, "", "partial", project="ProjetoA", cpu="CPU_1", limit=1, offset=1)
            tag_total, _ = search_occurrences(database_path, "", "partial", category="tag")
            literal_total, _ = search_occurrences(database_path, "FB_", "partial")
            selected = get_occurrence(database_path, exact_results[0].id)
            context = inspect_source(root / "refs", selected)

        self.assertEqual(partial_total, 3)
        self.assertEqual(len(partial_results), 3)
        self.assertEqual(exact_total, 1)
        self.assertEqual(exact_results[0].name, "FB_Ventil")
        self.assertIsNotNone(selected)
        self.assertEqual(context.block_name, "FB_Ventil")
        self.assertEqual(context.block_kind, "FB")
        self.assertIsNotNone(context.candidate_line)
        self.assertEqual(missing_total, 0)
        self.assertEqual(missing_results, [])
        self.assertEqual(all_total, 3)
        self.assertNotEqual(first_page[0].id, second_page[0].id)
        self.assertEqual(tag_total, 1)
        self.assertEqual(literal_total, 2)

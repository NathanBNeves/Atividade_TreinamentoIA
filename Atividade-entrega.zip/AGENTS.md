# Diretrizes do Repositório

## Estrutura do Projeto e Organização dos Módulos

`refs/` contém as exportações XML originais do VASS06/TIA Portal. Trate-a como somente leitura: nunca reformate, mova, renomeie ou versione seu conteúdo. As referências atuais são `V6-39E001.ap17`, `V6-39E201.ap17`, `V6-39E202.ap17`, `V6-39E220.ap17`, `V6-39E221.ap17` e `V6-39E231.ap17`.

`README.md` é o enunciado e a fonte dos requisitos; `Levantamento.md` registra achados manuais; os SVGs na raiz são ativos de interface e documentação. A aplicação ainda não foi criada. Ao adicioná-la, mantenha o código Python em `src/`, templates e ativos estáticos em `src/web/` e testes em `tests/`. Mantenha índices, bancos, logs e caches gerados em `data/` ou `tmp/`, ignorados pelo Git.

## Tecnologia e Execução

A linguagem definida é **Python 3.13+**. A primeira versão será uma aplicação web local com Flask, XML da biblioteca padrão e SQLite; não requer Node.js, Docker ou serviços externos. Enquanto o ponto de entrada não existir, registre no `andamento.md` o comando real escolhido. O comando esperado é `python -m src.app`; ele deverá iniciar a interface local e informar a URL no terminal.

## Categorias Pesquisáveis

- **Bloco:** unidade de lógica do PLC, como FB, FC ou OB.
- **Chamada:** execução de um bloco por outro trecho do programa.
- **Variável local:** dado da interface, temporário ou estático de um bloco.
- **DB e membro de DB:** armazenamento estruturado global ou um campo dentro dele.
- **Tag:** referência a sinal ou variável global.
- **Instância:** memória/objeto associado à execução de um FB.
- **Constante e tipo:** valor fixo ou definição de estrutura usada pela lógica.

Cada ocorrência deve indicar se declara, chama, instancia, lê, escreve, acessa um membro, referencia um tipo ou apenas cita o nome em comentário.

## Expectativas de Arquitetura

Crie uma ferramenta Python local que indexe metadados dos XMLs antes de atender pesquisas. Preserve, em cada resultado, projeto, CPU (quando identificável), caminho relativo, localização no arquivo/elemento, trecho original, categoria e confiança. Classifique ocorrências separadamente como declaração, chamada, instância, leitura, escrita, acesso a membro de DB, referência de tipo ou comentário. Informe falhas de análise e construções XML não suportadas; não apresente resultados incertos como fatos.

## Comandos de Desenvolvimento e Teste

Use um ambiente virtual e instale as dependências após elas serem definidas:

```powershell
python -m venv .venv
.\.venv\Scripts\Activate.ps1
python -m pip install -r requirements.txt
python -m unittest discover -s tests -v
```

Execute a aplicação local pelo ponto de entrada documentado (esperado: `python -m src.app`). Não adicione Node.js, Docker ou serviços externos sem uma necessidade comprovada pelos requisitos.

## Estilo de Código e Convenções de Nomes

Use Python 3.13+, indentação de quatro espaços, anotações de tipo em funções públicas e `snake_case` para arquivos, funções e variáveis. Use `PascalCase` para classes. Prefira o analisador XML e o SQLite da biblioteca padrão, exceto quando uma dependência melhorar materialmente a correção. Nomeie testes como `test_<comportamento>.py`; use *fixtures* explícitas, sem depender da árvore completa de `refs/`.

## Comentários Didáticos

Inclua comentários curtos em cada etapa relevante do fluxo do programa para explicar a intenção da leitura, classificação, indexação, pesquisa e apresentação dos dados. Priorize decisões, transformações e regras de negócio; não comente instruções Python autoexplicativas. Mantenha os comentários em português e atualize-os quando o comportamento correspondente mudar.

## Diretrizes de Teste

Teste busca exata/parcial sem diferenciar maiúsculas de minúsculas, filtros combinados de projeto/CPU/categoria, cada classificação de uso e XMLs inválidos ou incompletos. Inclua *fixtures* XML pequenas e sanitizadas para chamadas de FB, variáveis temporárias, membros de DB global e comentários. Uma resposta sem resultados só é válida após o escopo-alvo ser concluído sem erros de análise.

## Diretrizes de Commit e Pull Request

Ainda não há histórico de commits; use mensagens curtas no imperativo, como `Adiciona classificador de ocorrências XML`. Mantenha cada commit focado. Antes de um pull request, execute os testes, descreva o comportamento visível ao usuário, liste limitações e inclua capturas de tela para alterações de interface. Nunca inclua `refs/`, índices gerados ou credenciais.

## Acompanhamento do Trabalho

Use `andamento.md` como registro oficial de continuidade. Após cada sessão, atualize data, funcionalidades concluídas, testes executados, limitações conhecidas, pendências e o comando validado para executar a aplicação. Atualize este arquivo quando a estrutura, dependências, categorias ou forma de execução mudar.

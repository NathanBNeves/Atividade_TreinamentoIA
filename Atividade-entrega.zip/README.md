# Desafio — Crie um explorador de projetos VASS06 com o Codex

Imagine que sua equipe precisa localizar exemplos de programação nos XMLs de seis CPUs de projetos de referência VASS06 da Volkswagen, sem ter que abrir cada projeto no TIA Portal e ficar procurando manualmente em cada um..

**Crie a ferramenta do zero usando a extensão do Codex no VS Code.** Ela deve pesquisar blocos, tags, variáveis e membros de DB, com filtros por projeto, CPU e tipo de elemento.

**O foco do exercício é aprender a desenvolver com IA:** fornecer contexto à IA, planejar, escrever pedidos claros, acompanhar o trabalho no VS Code, revisar alterações, usar Git, investigar erros e validar resultados com conhecimento de engenharia.

Você está livre para escolher a linguagem, as bibliotecas e a forma de visualização que achar melhores. Pode criar uma aplicação web local, uma aplicação desktop, uma ferramenta de terminal ou outra solução. Escolha algo que consiga executar, conferir e explicar. Uma interface simples pode atender muito bem ao desafio.

## Material disponível

| Arquivo ou pasta | Uso |
| --- | --- |
| `refs/` | XMLs organizados por projeto, CPU e pastas de programa. Preserve os originais. |
| `roteiro.md` | Conteúdo do treinamento. |


| Comando | Breve descrição |
|---|---|
| `/init` | Gera um `AGENTS.md` com instruções iniciais para trabalhar no projeto. Revise o arquivo criado. |
| `/plan` | Ativa ou desativa o modo de planejamento para discutir a solução antes de implementar. |
| `/status` | Mostra informações da sessão, uso de contexto da IA e limites disponíveis. |
| `/compact` | Resume o contexto da IA para continuar uma conversa longa. |
| `/model` | Permite escolher o modelo e, quando disponível, o esforço de raciocínio. |
| `/goal` | Define um objetivo para o Codex continuar trabalhando até atingir os critérios estabelecidos. |

## Etapa 0 — Instale as ferramentas e abra o projeto

### Prepare as contas e o VS Code

1. Crie uma conta no [GitHub](https://github.com/signup), caso ainda não tenha.
2. Baixe e instale o [Git para Windows](https://git-scm.com/downloads/win).
3. Baixe e instale o [Visual Studio Code](https://code.visualstudio.com/download).
4. No VS Code, acesse **Arquivo > Abrir Pasta** e selecione a pasta deste exercício ou crie uma nova.
5. No ícone **Contas**, entre com sua conta do GitHub. Se a opção de entrada não aparecer, abra a Paleta de Comandos com `Ctrl+Shift+P`, procure **Settings Sync: Turn On...** e escolha entrar com GitHub. Conclua a autorização no navegador e volte ao VS Code.
6. Abra **Extensões** com `Ctrl+Shift+X`, procure **Codex**, confira que o publicador é a **OpenAI** e instale a extensão.
7. Abra o ícone do Codex na barra lateral. Se não aparecer, use `Ctrl+Shift+P` e procure **Codex: Open Codex Sidebar**.
8. Faça login no Codex com a conta ChatGPT habilitada para o treinamento. Esse login é separado do login no GitHub.


O Codex será usado pelo painel do VS Code durante todo o exercício. As operações de Git serão feitas pelo **Controle do Código-Fonte** no vscode, sem necessidade de digitar comandos Git no terminal.

### Prepare o versionamento

1. Abra **Controle do Código-Fonte** com `Ctrl+Shift+G` e clique em **Inicializar Repositório / Initialize Repository**, se a pasta ainda não tiver um repositório.
2. Peça ao Codex para criar um `.gitignore` que exclua `refs/` e o que mais achar que não deve fazer parte do versionamento.
3. Se o Git ainda não tiver nome e e-mail de autor configurados, peça ao Codex ajuda para configurar esses dados. Entrar no GitHub não substitui essa configuração do git.

**Precisa de um ponto de partida?**

> Quero desenvolver esta ferramenta do zero. Primeiro confira a organização da pasta e o estado do Git. Explique como organizar o código e os arquivos gerados, preservando as referências. Ajude-me a preparar o versionamento local.

### Como registrar um commit pelo VS Code

Um commit guarda uma versão dos arquivos selecionados, para fazer de forma manual:

1. Salve os arquivos e abra **Controle do Código-Fonte**.
2. Clique em cada arquivo de **Alterações / Changes** para revisar o conteúdo. Em arquivos modificados, o diff mostra o que foi acrescentado e removido.
3. Clique no **+** ao lado dos arquivos que deseja incluir. Eles passam para **Alterações Preparadas / Staged Changes**.
4. Escreva uma mensagem, como `Prepara o exercício e ignora referências`.
5. Clique em **Commit** e localize o registro no **Grafo do Controle do Código-Fonte / Source Control Graph**.

Faça esse primeiro commit com pelo menos o `.gitignore`.

Também é possível pedir ao Codex: “Revise as alterações e registre um commit somente dos arquivos de código e documentação. Não inclua as referências”. Confira depois quais arquivos entraram no commit pelo VS Code.

O commit fica no computador. A conta GitHub será usada se você publicar o código na etapa 7.

## Etapa 1 — Descubra o que existe nos XMLs

No painel do Codex, use `/status` para consultar as informações da sessão e o uso de contexto da IA. Os comandos iniciados por `/` deste exercício são digitados nessa conversa.

**Exemplo de pedido:**

> Examine a organização de refs/ e selecione uma amostra de XMLs de diferentes tipos de bloco e linguagem. Localize uma definição de bloco, uma chamada, uma variável local e um acesso a membro de DB. Investigue também onde aparecem referências a tags globais. Para cada exemplo, indique arquivo e trecho. Informe o que não conseguiu interpretar.

Abra os arquivos indicados no VS Code, faça perguntas sobre eles, confira você mesmo pelo menos um para entender como é sua estrutura. Peça ao Codex que registre em `levantamento.md` as categorias encontradas, os exemplos e as limitações que possa ter encontrado.

Uma referência a uma tag no código não significa que sua declaração esteja nas exportações. Separe essas situações no levantamento.

Use `/status` novamente. Se a análise produziu muito texto, peça um resumo com os caminhos dos arquivos e apenas os trechos necessários, não faça ter que ler todos os arquivos xml pois isso utilizara muitos dos tokens.

Investigue coisas como:

- Como identificar projeto, CPU, bloco e pasta de programa.
- Como distinguir a definição de um bloco de uma chamada a esse bloco.
- Onde aparecem variáveis locais, referências a tags e membros de DB.
- Como identificar a localização de uma ocorrência: network, título, comentário ou trecho de código.
- Quais linguagens e estruturas de XML exigem tratamentos diferentes.
- Quais informações estão ausentes ou ainda não puderam ser interpretadas.

## Etapa 2 — Defina a busca e escolha a tecnologia

Digite `/plan` para discutir a implementação antes de criar o código.

**Pedido sugerido:**

> Planeje uma ferramenta para pesquisar os XMLs dos seis projetos. Compare duas opções de linguagem e apresentação adequadas a este computador. Quero filtros por projeto, CPU e categoria: blocos, tags, variáveis locais e membros de DB. Proponha a organização dos arquivos e a sequência de implementação. Ainda não escreva o código.

Discuta com o Codex estas regras e registre as decisões em `requisitos.md`:

| Recurso | Regra a definir |
| --- | --- |
| Texto pesquisado | Nome exato ou parte do nome; tratamento de maiúsculas e minúsculas. |
| Categorias | Separar blocos, tags, variáveis locais e membros de DB. Acrescentar outras categorias se forem úteis. |
| Ocorrência | Distinguir definição, declaração, chamada, referência no código e menção em comentário. |
| Filtros | Permitir combinar projeto, CPU e categoria, além de limpar a seleção. |
| Resultado | Mostrar nome, categoria, projeto, CPU, bloco, arquivo e trecho da ocorrência. Mostrar network e título quando identificáveis. |
| Falhas e limitações | Informar arquivos não lidos e categorias ou linguagens sem suporte. |

Escolha a linguagem e a visualização com auxílio do Codex. Peça alternativas simples e avalie instalação, facilidade de execução, leitura dos XMLs e apresentação dos resultados. Registre a decisão e o escopo em `requisitos.md`.

## Etapa 3 — Crie as instruções para o Codex

Se o modo de planejamento continuar ativo, use `/plan` para sair dele. Digite `/init` no painel do Codex para gerar o `AGENTS.md` e abra o arquivo criado no VS Code.

Em seguida, peça que inclua no arquivo orientações relacionadas as suas decisões do projeto:

- Onde ficam as referências e quais arquivos devem ser preservados.
- A linguagem escolhida e a organização do código.
- O significado das categorias de busca e a cobertura esperada.
- A exigência de manter projeto e CPU na identificação das ocorrências.
- Como executar e verificar a aplicação, conforme esses comandos forem definidos.
- Onde registrar limitações e andamento.

Confira se o arquivo reflete suas decisões e remova instruções que não se aplicam ao projeto.

No Controle do Código-Fonte, revise `levantamento.md`, `requisitos.md` e `AGENTS.md`, clique no **+** desses arquivos e registre o commit `Define requisitos e instruções do explorador`.

## Etapa 4 — Implemente e confira a busca

Peça ao Codex para implementar uma parte de cada vez. Depois de cada parte, execute a aplicação e faça as verificações abaixo.

### Parte A — Ler uma amostra e pesquisar

> Implemente a leitura da amostra registrada em levantamento.md e a busca por nome de bloco. Mostre projeto, CPU, bloco, tipo de ocorrência, caminho do XML e trecho encontrado. Explique como iniciar a aplicação pelo terminal integrado do VS Code.

Pesquise um bloco identificado na etapa 1. Abra o XML indicado no resultado e confira o nome e a classificação. Pesquise também um nome inexistente e verifique a mensagem apresentada.

### Parte B — Acrescentar categorias e filtros

> Acrescente as categorias que pensou e anotou em requisitos.md e os filtros por projeto e CPU. Mantenha separadas as ocorrências de mesmo nome em arquivos diferentes. Informe as categorias que dependem de dados ausentes ou ainda não têm suporte.

Escolha no levantamento um exemplo de cada categoria disponível. Pesquise cada um, aplique um filtro de projeto e confira se os resultados pertencem ao projeto selecionado. Limpe os filtros e verifique se as ocorrências dos demais projetos voltam a aparecer.

### Parte C — Processar os seis projetos

> Amplie a leitura para os seis projetos e apresente quantos arquivos foram processados, quais falharam e quais estruturas não foram interpretadas. Evite reler todos os XMLs a cada alteração de filtro.

Pesquise um nome presente em mais de um projeto. Confira que os resultados mantêm projeto e CPU separados.

Após as verificações de cada parte, peça ao Codex: “Revise as alterações ainda não registradas no Git. Procure erros na classificação dos elementos, nos filtros e na identificação de projeto e CPU. Apresente os problemas e os arquivos envolvidos antes de corrigir”. Avalie os apontamentos e peça as correções necessárias. Pelo Controle do Código-Fonte, abra os arquivos alterados, revise o diff.

Quanto julgar necessário faça commits ou peça para que o agente realize um commit com comentários.

## Etapa 5 — Investigue erros e crie verificações repetíveis

Se encontrar um resultado incorreto, informe ao Codex a pesquisa realizada, os filtros ativos, o resultado recebido e o esperado.

**Exemplo:**

> Pesquisei FB_Ventil com nome exato e filtro no projeto V6-39E231.ap17. O resultado incluiu a definição do bloco como se fosse uma chamada. Reproduza o problema e mostre por que a classificação ficou errada antes de alterar o código.

Peça sugestões de testes automatizados para garantir que as funcionalidades que implementou continuam funcionando conforme vai adicionando funcionalidades.

Após corrigir um erro, repita a pesquisa que o revelou e execute os testes afetados. Peça ao Codex para revisar a correção e procurar efeitos nas outras categorias de busca. Depois, revise os arquivos no Controle do Código-Fonte e faça o commit pelo procedimento da etapa 0.

## Etapa 6 — Acrescente uma função à sua escolha

Antes de alterar o código, crie uma branch no VS Code: clique no nome da branch na barra inferior, escolha **Criar nova branch / Create new branch** e dê um nome, como `catalogo-blocos`.

se quiser use `/plan`, escolha uma das opções abaixo e peça um plano. Depois de revisar a proposta e discutir ideias siga com a implementação.

### Opção A — Catálogo: consultar os blocos sem saber o nome completo

**Objetivo:** navegar por uma lista dos FBs e FCs disponíveis e consultar seus parâmetros.

Acrescente uma tela ou listagem com nome do bloco, tipo, descrição disponível e projetos em que sua definição existe. A ideia é criar uma lista de consulta dos blocos disponíveis, semelhante a uma biblioteca. A pessoa poderia navegar pelos nomes, ler as descrições e consultar os parâmetros sem abrir o TIA, ver quais os mais usados e consultar onde foram usados.

Por exemplo: a lista mostra todos os blocos usados, você filtra por `Ventil`, selecione `FB_Ventil` e consulte seus parâmetros de entrada. Ofereça uma ação **Procurar chamadas deste bloco**, que abre a busca já preenchida com o nome exato.

**Verificação:** compare três parâmetros com a definição no XML. Acione a busca de chamadas e confira que ela lista usos, sem incluir a definição como chamada. O catálogo consulta declarações; não precisa desenhar a lógica do bloco.

E se for possível abrir a documentação do bloco direto pela sua ferramenta.


### Opção B — Matriz de utilização

**Situação de uso:** uma pessoa conhece o nome de um bloco e quer identificar em quais projetos existem exemplos de chamada antes de decidir qual consultar.

Crie uma tabela em que cada linha representa o nome de um bloco chamado e cada coluna identifica um par projeto/CPU. Para esta atividade, conte **chamadas explícitas encontradas no código**. Definições, declarações de instância e menções em comentários ficam fora dessa contagem.

Exemplo ilustrativo de apresentação, com valores fictícios:

| Bloco chamado | Projeto A / CPU 1 | Projeto B / CPU 2 | Projeto C / CPU 3 |
| --- | ---: | ---: | --- |
| `FB_Ventil` | 5 | 0 | Não processado |
| `FB_Ventil_01E` | 2 | 8 | Não processado |

Permita filtrar linhas pelo nome do bloco e ordenar pela quantidade de projetos com chamadas encontradas.

Ao selecionar uma célula com chamadas, mostre a lista que compõe a contagem: bloco chamador, network ou trecho de código, instância e arquivo de origem. Uma célula com zero significa que o escopo foi processado sem chamadas identificadas. Se houver linguagens ainda sem suporte, falhas ou processamento incompleto, sinalize a cobertura parcial em vez de apresentar um zero.

**Verificação:** escolha uma ocorrências, abra sua lista e confira no tia ou no XML se o que está sendo apresentado condiz com a realidade.


### Revise e integre a função escolhida

Use a aplicação e faça uma rodada de ajustes e commits quando julgar necessário.
Para integrar a função que implementou de volta ao branch principal peça ajuda para o codex de como fazer isso caso não saiba.

## Etapa 7 — Documente, retome e compartilhe o código

Peça ao Codex que crie `COMO_USAR.md` com instalação, execução, filtros, exemplos de pesquisa, testes e limitações. Preserve este README como enunciado.

Peça também um `andamento.md` com funções concluídas, testes executados e pendências. Abra uma nova conversa no painel do Codex e envie:

> Leia AGENTS.md, requisitos.md e andamento.md. Confira os arquivos do projeto e explique o que funciona, o que falta e como executar a ferramenta. Não altere nada ainda.

Compare a resposta com a aplicação. Se uma decisão importante se perdeu, acrescente-a ao documento apropriado.

Para continuar na mesma conversa quando ela estiver longa, use `/compact` após salvar essas decisões. O comando resume o contexto da IA; os arquivos permitem consultar os detalhes depois.

Se quiser, peça ajuda para saber como publicar o repositório no seu github.

## Confira o resultado do exercício

- [ ] A aplicação foi criada do zero e sua execução está documentada.
- [ ] A busca processa os seis projetos e combina filtros por projeto, CPU e categoria.
- [ ] Blocos, tags, variáveis e membros de DB têm tratamento definido; dados ausentes e tipos sem suporte são informados.
- [ ] Os resultados mostram a origem no XML e distinguem declarações de usos.
- [ ] Catálogo ou matriz foi implementado e conferido.
- [ ] Há testes para nomes semelhantes, classificação e filtros.
- [ ] O histórico do Git registra as funções construídas, e uma delas foi desenvolvida em uma branch.
- [ ] Os XMLs originais foram preservados.

## Se terminou
O agente consegue usar sua ferramenta? por exemplo, se fizer um pedido para o agente ele consegue executar o seu programa, fazer a busca, aplicar os filtros e te retornar o que perguntou sem que o próprio agente tenha que ler todos os XMLs? Se sim, consegue criar uma skill para o codex ter instruções de como  e quando deve usar a sua ferramenta?

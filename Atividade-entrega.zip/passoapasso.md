# Passo a passo — Explorador de XML VASS06

Este arquivo resume os passos aprovados e concluídos do projeto. Cada próximo passo será acrescentado após sua aprovação e atualizado com o resultado da validação.

## Passo 1 — Preparar o ambiente

**Objetivo:** preparar o Python e as dependências da aplicação local.

**Criado ou alterado:**

- `.venv/`, ambiente virtual local, ignorado pelo Git.
- `requirements.txt`, com Flask como dependência da aplicação.
- `.gitignore`, para manter `refs/`, `.venv/`, `data/`, `tmp/` e caches fora do versionamento.

**Validação:** Python 3.13.17 e Flask 3.1.3 disponíveis no ambiente virtual.

## Passo 2 — Criar a estrutura inicial

**Objetivo:** disponibilizar a primeira página web local.

**Criado ou alterado:**

- `src/__init__.py`, que identifica o pacote Python da aplicação.
- `src/app.py`, ponto de entrada Flask com a rota inicial `/`.
- `src/web/templates/index.html`, página inicial da ferramenta.
- Pastas `tests/`, `data/` e `tmp/`.

**Validação:** a aplicação respondeu HTTP 200 em `http://127.0.0.1:5000` pelo comando abaixo.

```powershell
.\.venv\Scripts\python.exe -m src.app
```

## Passo 3 — Inventariar as referências

**Objetivo:** encontrar e validar os XMLs sem modificar os arquivos de referência.

**Criado ou alterado:**

- `src/inventory.py`, que localiza XMLs, infere projeto e CPU pelo caminho e registra falhas de leitura.
- `tests/test_inventory.py`, teste com XML válido e inválido para garantir que uma falha não interrompe o inventário.
- `src/app.py` e `src/web/templates/index.html`, que exibem o resumo do inventário na página inicial.

**Validação:** 5.250 XMLs encontrados e lidos, 0 falhas; teste automatizado aprovado.

**Como conferir:** inicie a aplicação e abra `http://127.0.0.1:5000` para consultar os totais e os seis projetos identificados.

## Passo 4 — Extrair e indexar elementos

**Objetivo:** transformar declarações XML explícitas em dados pesquisáveis, sem reler os XMLs quando a busca for criada.

**Criado ou alterado:**

- `src/extractor.py`, extrator de declarações explícitas de blocos, DBs, membros de DB, tags, variáveis locais e tipos.
- `src/index_store.py`, esquema SQLite, gravação do índice e leitura dos totais sem reprocessar os XMLs.
- `data/index.sqlite3`, banco gerado localmente e ignorado pelo Git.
- `tests/test_extractor.py`, fixture XML sanitizada que verifica extração e persistência.
- `src/app.py` e `src/web/templates/index.html`, com o estado da indexação, totais por categoria e limitações ainda conhecidas.

**Validação:** dois testes automatizados aprovados; 5.250 XMLs processados, sem falhas; 221.603 declarações indexadas.

**Cobertura atual:** blocos, DBs, membros de DB, tags, variáveis locais e tipos declarados. Chamadas, instâncias, leituras, escritas, constantes fora de interfaces, referências de tipo no código e comentários são mostrados como não suportados, sem inferência.

## Passo 5 — Classificar o uso

**Objetivo:** separar papéis de ocorrência que aparecem explicitamente nos XMLs, mantendo limitações claras para as linguagens ainda não interpretadas.

**Criado ou alterado:**

- `src/extractor.py`, ampliado para reconhecer `CallInfo`, `Instance`, comentários, constantes literais e referências de tipo por `Datatype`.
- `src/index_store.py`, ampliado com o motivo da classificação e uma migração compatível do banco SQLite já existente.
- `src/rebuild_index.py`, comando interno para reconstruir o índice local após uma alteração de extração.
- `tests/test_extractor.py`, ampliado com chamadas, instâncias, comentário e constante na fixture sanitizada.
- `src/app.py` e `src/web/templates/index.html`, ampliados com os papéis disponíveis e as limitações da cobertura.

**Validação:** dois testes automatizados aprovados; 5.250 XMLs reprocessados sem falhas; página validada com HTTP 200.

**Cobertura atual:** 6.034 chamadas, 4.986 instâncias, 127.863 comentários, 67.972 constantes e 6.043 referências de tipo, além das declarações do passo 4. Leituras, escritas e acesso a membros de DB continuam sem suporte. Comentários são encontrados pelo próprio texto e não são tratados como prova de uso de um nome citado.

## Passo 6 — Construir a pesquisa e filtros

**Objetivo:** consultar o índice sem reler os XMLs, com correspondência exata ou parcial e filtros combináveis.

**Criado ou alterado:**

- `src/index_store.py`, ampliado com consulta SQLite parametrizada e listagem dos valores de filtro.
- `src/app.py` e `src/web/templates/index.html`, ampliados com formulário de busca, ação para limpar filtros e resultados com origem, papel, confiança, motivo e trecho XML.
- `tests/test_search.py`, que verifica busca exata, parcial sem distinção de caixa e filtros combinados.

**Validação:** três testes automatizados aprovados; busca web por `FB_Ventil` validada com HTTP 200.

## Passo 7 — Tornar a análise transparente

**Objetivo:** impedir que ausência de resultado seja apresentada como certeza quando a cobertura do XML ou da linguagem for parcial.

**Criado ou alterado:**

- A interface passou a descrever todas as categorias disponíveis.
- Pesquisas sem resultado mostram um aviso de cobertura limitada.
- A página mostra construções não interpretadas e exibirá detalhes de falhas de leitura ou indexação quando ocorrerem.

**Validação:** três testes automatizados aprovados; busca por nome inexistente validada com HTTP 200 e aviso de cobertura exibido.

## Passo 8 — Testar e documentar

**Objetivo:** disponibilizar instruções de instalação, execução, testes e limitações para continuidade do projeto.

**Criado ou alterado:**

- `COMO_USAR.md`, com instalação, execução, reindexação, filtros, exemplos, testes e limitações.
- `andamento.md`, atualizado com o estado do MVP, testes e pendências.

**Validação:** a suíte de testes contém cobertura para XML inválido, declarações e classificações explícitas, busca exata/parcial sem distinção de caixa e filtros combinados.

## Próximos aprimoramentos

- Interpretar leituras, escritas e acesso a membros de DB nas linguagens dos blocos.
- Criar catálogo de blocos ou matriz de utilização como recurso posterior ao MVP.

## Passo 9 — Refinar a interface visual

**Objetivo:** tornar a consulta mais agradável e clara no navegador, preservando os dados e filtros existentes.

**Criado ou alterado:**

- `src/web/static/styles.css`, com tema escuro, paleta roxa, cartões, responsividade e estados visuais para busca e resultados.
- `src/web/templates/index.html`, reorganizado em cabeçalho, painel de pesquisa, cartões de resultado, métricas e painéis de cobertura.
- `src/app.py`, configurado para servir os arquivos estáticos a partir de `src/web/static/`.

**Validação:** três testes automatizados aprovados; página com busca por `FB_Ventil` validada com HTTP 200 e folha de estilos carregada.

## Passo 10 — Detalhar a origem de uma ocorrência

**Objetivo:** permitir abrir uma ocorrência da pesquisa e consultar seu contexto de trabalho sem procurar manualmente em milhares de XMLs.

**Criado ou alterado:**

- `src/index_store.py`, ampliado para identificar cada resultado e recuperá-lo pela chave do SQLite.
- `src/source_context.py`, que reconstrói o bloco/função e localiza uma linha candidata no XML original somente ao abrir o detalhe.
- `src/web/templates/occurrence_detail.html`, página de detalhe com árvore de projeto, CPU, pastas, arquivo, bloco, elemento e ocorrência.
- `src/app.py` e `src/web/templates/index.html`, com a rota `/occurrences/<id>` e a ação **Abrir análise da ocorrência**.
- `src/web/static/styles.css`, ampliado para a visualização em árvore e a composição de marca.
- O logo vertical branco e o símbolo colorido, preservados na raiz, são servidos em rotas específicas e combinados no cabeçalho sem alterar os SVGs originais.

**Validação:** três testes automatizados aprovados; página de detalhe, logo vertical e símbolo colorido validados com HTTP 200.

## Passo 11 — Explorar sem conhecer nomes

**Objetivo:** navegar por projetos, CPUs e categorias mesmo sem saber o nome de um elemento.

**Criado ou alterado:**

- Busca sem texto, filtros combináveis e paginação para percorrer os resultados.
- Árvore navegável de projeto, CPU e categoria, com contagens de ocorrências.
- Extração corrigida para usar o nome real do bloco (`AttributeList/Name`) em vez do metadado `HeaderName`.
- Indicação de linha mais conservadora e tratamento literal de `%` e `_` na busca parcial.
- `COMO_USAR.md` e testes atualizados com o novo fluxo.

**Limitações:** leituras, escritas e acessos a membros de DB em código continuam sem interpretação; as contagens e a árvore abrangem as ocorrências indexadas, não todos os elementos possíveis dos projetos.

**Validação:** três testes automatizados aprovados; 5.250 XMLs reindexados sem falhas; navegação por DB, paginação por CPU e busca exata de `FB_Ventil` verificadas na aplicação.

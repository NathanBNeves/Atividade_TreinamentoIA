# Andamento — Explorador de XML VASS06

## Objetivo da primeira versão

Criar uma aplicação web local que pesquisa os XMLs em `refs/` por nome exato ou parcial, sem diferenciar maiúsculas de minúsculas. Os resultados devem filtrar por projeto, CPU e categoria, mostrar arquivo, localização, trecho, papel da ocorrência e limitações de leitura.

## Plano de execução

### 1. Preparar o ambiente

- [x] Confirmar `python --version` (Python 3.13.17).
- [x] Criar `.venv` e instalar Flask 3.1.3.
- [x] Criar `requirements.txt`.

**Concluído quando:** `python` e `pip` funcionarem no terminal do VS Code.

### 2. Criar a estrutura inicial

- [x] Criar `src/`, `src/web/`, `tests/`, `data/` e `tmp/`.
- [x] Criar o ponto de entrada `src/app.py`.
- [x] Exibir uma página local vazia e documentar o comando de execução.

**Concluído quando:** `python -m src.app` abrir a aplicação no navegador.

### 3. Inventariar as referências

- [x] Encontrar os seis projetos dentro de `refs/`.
- [x] Identificar CPUs e arquivos XML por projeto, a partir dos níveis do caminho relativo.
- [x] Registrar XMLs ilegíveis sem interromper o processamento.

**Concluído quando:** a aplicação informar quantos arquivos foram encontrados, lidos e falharam.

### 4. Extrair e indexar elementos

- [x] Extrair declarações explícitas de blocos, DBs, membros de DB, tags, variáveis locais e tipos; chamadas, instâncias, constantes e referências no código permanecem sinalizadas como não suportadas.
- [x] Guardar projeto, CPU, caminho, elemento/localização, trecho XML e confiança alta para as declarações explícitas.
- [x] Persistir as ocorrências em SQLite, em `data/index.sqlite3`.

**Concluído quando:** uma amostra do projeto atual localizar FB, chamada, `Temp` e membro de DB.

### 5. Classificar o uso

- [x] Distinguir declaração, chamada, instância, referência de tipo e comentário quando expressos em elementos XML próprios.
- [ ] Interpretar leituras, escritas e acesso a membro de DB dentro das linguagens dos blocos; a cobertura permanece explicitamente parcial.
- [x] Guardar confiança alta e motivo para cada classificação atualmente suportada; classificações parciais não são apresentadas como certeza.

**Concluído quando:** um elemento usado mais de uma vez mostra cada papel separadamente.

### 6. Construir a pesquisa e filtros

- [x] Implementar busca exata/parcial sem distinção de maiúsculas.
- [x] Adicionar filtros por projeto, CPU e categoria.
- [x] Mostrar a descrição básica de cada categoria na interface.

**Concluído quando:** uma pesquisa combina texto e filtros corretamente.

### 7. Tornar a análise transparente

- [x] Mostrar arquivos incompletos, inválidos ou não interpretados.
- [x] Não apresentar inferências incertas como certeza.
- [x] Exibir o trecho XML que sustenta cada resultado.

**Concluído quando:** a tela diferencia “não encontrado” de “não foi possível analisar”.

### 8. Testar e documentar

- [x] Criar testes para busca, filtros, classificação e XML inválido.
- [x] Executar `python -m unittest discover -s tests -v`.
- [x] Criar `COMO_USAR.md` com instalação, execução e limitações.

**Concluído quando:** os testes passarem e uma pessoa consiga executar a ferramenta seguindo a documentação.

## Próxima etapa posterior ao MVP

- [ ] Construir relações `declara`, `chama`, `lê`, `escreve`, `instancia` e `acessa membro de`.
- [ ] Exibir onde o elemento aparece e quais elementos ele pode afetar.

## Passo 9 — Refinar a interface visual

- [x] Aplicar tema escuro com paleta roxa.
- [x] Organizar busca, filtros, resultados, métricas e limitações em painéis responsivos.
- [x] Validar a página redesenhada e preservar o comportamento de pesquisa.

## Passo 10 — Detalhar a origem de uma ocorrência

- [x] Criar página individual para a ocorrência selecionada na pesquisa.
- [x] Mostrar árvore de projeto, CPU, pastas, arquivo, bloco/função, elemento e ocorrência.
- [x] Exibir trecho XML, motivo, confiança e linha candidata com limitação explícita.
- [x] Integrar o logo vertical branco com o símbolo colorido no cabeçalho.

## Passo 11 — Explorar sem conhecer nomes

- [x] Permitir consulta sem texto por projeto, CPU e categoria, com paginação.
- [x] Adicionar árvore navegável por projeto, CPU e tipo de ocorrência.
- [x] Corrigir o nome de blocos para usar `AttributeList/Name` em vez de `HeaderName`.
- [x] Evitar sugerir uma linha quando há múltiplas candidatas.
- [ ] Interpretar leituras, escritas e acessos a membros de DB nas linguagens dos blocos, com testes específicos.

## Registro da sessão atual

- **Data:** 12/11/2026.
- **Situação:** MVP concluído: a aplicação inventaria, indexa e pesquisa as estruturas XML atualmente suportadas.
- **Tecnologia definida:** Python 3.13+, Flask, XML da biblioteca padrão e SQLite.
- **Comando validado para execução:** `.\.venv\Scripts\python.exe -m src.app` (abre `http://127.0.0.1:5000`).
- **Testes executados:** Python 3.13.17; instalação do Flask 3.1.3; rota `/` por cliente Flask; servidor local com resposta HTTP 200; `python -m unittest discover -s tests -v` (2 testes aprovados); inventário real com 5.250 XMLs encontrados e lidos, sem falhas; página de indexação validada com HTTP 200.
- **Índice atual:** 434.501 ocorrências em SQLite, incluindo 982 declarações de bloco, 6.034 chamadas, 4.986 instâncias, 127.863 comentários, 67.972 constantes e 6.043 referências de tipo; além das declarações já indexadas na etapa 4.
- **Limitação conhecida:** leituras, escritas e acesso a membros de DB no código ainda exigem interpretação adicional das linguagens; comentários são pesquisáveis pelo texto, mas não provam que um nome citado foi usado.
- **Pendência:** implementar a interpretação de leituras, escritas e acessos a membros de DB; considerar catálogo ou matriz de utilização após o MVP.
- **Próxima ação:** revisar as alterações no Controle do Código-Fonte e criar um commit inicial.
- **Última atualização visual:** interface escura roxa criada em `src/web/static/styles.css`; página validada com HTTP 200 e três testes automatizados aprovados.
- **Última atualização funcional:** página `/occurrences/<id>` criada para analisar uma ocorrência; árvore e ativos de marca validados com HTTP 200.
- **Sessão de 12/11/2026:** passo 11 adiciona exploração por projeto/CPU/categoria e corrige nomes de blocos. Testes: `python -m unittest discover -s tests -v`. Pendências anteriores de classificação permanecem abertas; o índice deve ser reconstruído após alterar o extrator.
